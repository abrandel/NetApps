key1='po9VttMkdr1VKeu9ATubNgEMr2idjqu-ce-6ZiIhtpt6'
url1='https://stream.watsonplatform.net/text-to-speech/api'
